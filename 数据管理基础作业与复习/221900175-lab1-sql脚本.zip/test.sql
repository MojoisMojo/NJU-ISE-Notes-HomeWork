-- single test for 3.9
INSERT INTO Customers VALUES ('c100', 'Mojo',   'Suzhou',    0.00);
INSERT INTO Orders VALUES (2001, '2027-01-28', 'c100', 'a04', 'p01', 1000, 460.00);
INSERT INTO Orders VALUES (2002, '2027-02-05', 'c100', 'a04', 'p01', 1000, 500.00);
INSERT INTO Orders VALUES (2003, '2027-02-05', 'c100', 'a04', 'p07', 600,  600.00);
INSERT INTO Orders VALUES (2004, '2027-03-12', 'c100', 'a04', 'p01', 800,  400.00);

-- single test for 3.6 & 3.7
INSERT INTO Products VALUES('p99', 'mama', 'Dallas', 111400, 0.50);
INSERT INTO Orders VALUES (2100, '2036-02-28', 'c002', 'a03', 'p99', 1000, 460.00);
INSERT INTO Orders VALUES (2101, '2036-02-28', 'c003', 'a03', 'p99', 1000, 460.00);
INSERT INTO Orders VALUES (2102, '2036-02-28', 'c001', 'a03', 'p99', 1000, 460.00);
INSERT INTO Orders VALUES (2103, '2036-02-28', 'c004', 'a03', 'p99', 1000, 460.00);
INSERT INTO Orders VALUES (2104, '2036-02-28', 'c006', 'a03', 'p99', 1000, 460.00);
INSERT INTO Orders VALUES (2105, '2036-02-28', 'c100', 'a04', 'p99', 1000, 460.00);

-- single test for 3.1 & 3.8 
INSERT INTO Agents VALUES ('a99', 'Mojo',  'York New York', 7);