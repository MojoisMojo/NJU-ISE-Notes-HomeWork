/* 创建 用户表 */
CREATE TABLE
    IF NOT EXISTS Customers (
        cid CHAR(4) NOT NULL PRIMARY KEY -- 编号 主键 
,
        cname CHAR(20) NOT NULL -- 姓名 
,
        city CHAR(20) -- 城市 
,
        discnt REAL -- 折扣 
    );


/* 创建 经销商 表 */
CREATE TABLE
    IF NOT EXISTS Agents (
        aid CHAR(3) NOT NULL PRIMARY KEY -- 编号 主键 
,
        aname CHAR(20) NOT NULL -- 名称 
,
        city CHAR(20) -- 城市 
,
        perc SMALLINT -- 佣金比例 
    );


/* 创建 商品表 */
CREATE TABLE
    IF NOT EXISTS Products (
        pid CHAR(3) NOT NULL PRIMARY KEY -- 编号 主键 
,
        pname CHAR(20) NOT NULL -- 名称 
,
        city CHAR(20) -- 城市 
,
        quantity INT NOT NULL -- 存货数量 
,
        price REAL NOT NULL -- 单价 
    );


/* 创建 订单表 注意这里 我 认为 需要使用 一下 外码 如果更新删除了那么就一同更新删除*/
CREATE TABLE
    IF NOT EXISTS Orders (
        ordno INT NOT NULL PRIMARY KEY -- 订单编号 
,
        orddate DATE NOT NULL -- 订单日期 
,
        cid CHAR(4) NOT NULL -- 顾客编号 
,
        aid CHAR(3) NOT NULL -- 经销商编号 
,
        pid CHAR(3) NOT NULL -- 商品编号 
,
        qty INT -- 数量 
,
        dols REAL -- 金额 这里规定的应该是这笔交易的总金额 
,
        Foreign KEY (cid) REFERENCES Customers (cid) ON UPDATE CASCADE ON DELETE CASCADE,
        Foreign KEY (aid) REFERENCES Agents (aid) ON UPDATE CASCADE ON DELETE CASCADE,
        Foreign KEY (pid) REFERENCES Products (pid) ON UPDATE CASCADE ON DELETE CASCADE
    );