-- 3.1 查询没有为居住在Duluth的任何顾客订购过任何商品的经销商的编号；
SELECT
    a.aid
FROM
    Agents a
WHERE
    NOT EXISTS (
        SELECT
            *
        FROM
            Customers c
        WHERE
            c.city = 'Duluth'
            AND EXISTS (
                SELECT
                    *
                FROM
                    orders o
                WHERE
                    o.cid = c.cid
                    AND o.aid = a.aid
            )
    );


-- 3.2.查询城市名称中含有字符串’New’的经销商的编号、名称和所在城市；
SELECT
    aid,
    aname,
    city
FROM
    Agents
WHERE
    city LIKE "%New%";


-- 3.3.查询仅通过a03和a05两个经销商订购过商品的顾客编号；
-- Method 1
SELECT
    c.cid
FROM
    Customers c
WHERE
    c.cid IN (
        SELECT
            cid
        FROM
            Orders
    )
    AND NOT EXISTS (
        SELECT
            *
        FROM
            Orders o
        WHERE
            o.cid = c.cid
            AND o.aid NOT IN ('a03', 'a05')
    );


-- Method2
SELECT
    cid
FROM
    Orders
GROUP BY
    cid
HAVING
    COUNT(DISTINCT aid) <= 2
    AND MAX(aid) IN ('a03', 'a05')
    AND MIN(aid) IN ('a03', 'a05');


-- 3.4.查询符合下述条件的商品的编号：至少有一个顾客通过与该顾客位于同一个城市的经销商订购过该商品；
SELECT DISTINCT
    o.pid
FROM
    Orders o,
    Customers c,
    Agents a
WHERE
    o.aid = a.aid
    AND o.cid = c.cid
    AND c.city = a.city;


-- 3.5.返回每一个顾客的第一份订单和最后一份订单，结果返回顾客编号、第一份订单及最后一份订单的订单编号和订购日期；
--（按照订单编号的大小区分订单的先后；如果一个顾客只有一份订单，那么该订单作为该顾客的第一份订单，他的最后一份订单属性返回空值；不需要考虑没有订单的顾客。）
-- Method 1
SELECT
    x.cid,
    x.ordno AS first_ord,
    x.orddate AS first_date,
    y.ordno AS last_ord,
    y.orddate AS last_date
FROM
    orders x,
    orders y
WHERE
    x.cid = y.cid
    AND x.ordno < y.ordno
    AND NOT EXISTS (
        SELECT
            *
        FROM
            orders z
        WHERE
            z.cid = x.cid
            AND (
                z.ordno < x.ordno
                OR z.ordno > y.ordno
            )
    )
UNION
SELECT
    o1.cid,
    o1.ordno,
    o1.orddate,
    NULL,
    NULL
FROM
    orders o1
WHERE
    NOT EXISTS (
        SELECT
            *
        FROM
            orders o2
        WHERE
            o2.cid = o1.cid
            AND o2.ordno <> o1.ordno
    );


-- Method 2
SELECT
    c.cid,
    t.first_ord,
    t.first_date,
    t.last_ord,
    t.last_date
FROM
    Customers c
    LEFT JOIN (
        SELECT
            cid,
            MIN(ordno) AS first_ord,
            MIN(orddate) AS first_date,
            CASE
                WHEN COUNT(ordno) = 1 THEN NULL
                ELSE MAX(ordno)
            END AS last_ord,
            CASE
                WHEN COUNT(ordno) = 1 THEN NULL
                ELSE MAX(orddate)
            END AS last_date
        FROM
            orders
        GROUP BY
            cid
    ) t ON c.cid = t.cid;


-- 3.6.在所有有顾客的城市中都被销售过的商品的编号；
-- Method 1
SELECT
    p.pid
FROM
    Products p
WHERE
    p.pid IN (
        SELECT DISTINCT
            pid
        FROM
            Orders
    )
    AND NOT EXISTS (
        SELECT
            *
        FROM
            (
                SELECT DISTINCT
                    city
                FROM
                    Customers
            ) t
        WHERE
            t.city NOT IN (
                SELECT DISTINCT
                    c.city
                FROM
                    Orders o,
                    Customers c
                WHERE
                    p.pid = o.pid
                    AND o.cid = c.cid
            )
    );


-- Method 2
SELECT
    t.pid
FROM
    (
        SELECT
            o.pid,
            COUNT(DISTINCT c.city) AS city_num
        FROM
            Orders o,
            Customers c
        WHERE
            o.cid = c.cid
        GROUP BY
            o.pid
    ) t
WHERE
    t.city_num = (
        SELECT
            COUNT(DISTINCT city)
        FROM
            Customers
    );


-- 3.7.查询居住在Dallas的所有顾客都订购过的商品编号；
-- Method 1
SELECT
    p.pid
FROM
    Products p
WHERE
    NOT EXISTS (
        SELECT
            *
        FROM
            (
                SELECT
                    *
                FROM
                    Customers c
                WHERE
                    c.city = 'Dallas'
            ) t
        WHERE
            t.cid NOT IN (
                SELECT DISTINCT
                    o.cid
                FROM
                    Orders o
                WHERE
                    o.pid = p.pid
            )
    );


-- Method 2
SELECT
    o.pid
FROM
    Orders o, Customers c
WHERE
    c.cid = o.cid
    AND c.city = 'Dallas'
GROUP BY
    o.pid
HAVING
    COUNT(DISTINCT c.cid) = (
        SELECT
            COUNT(DISTINCT cid)
        FROM
            Customers WHERE city = 'Dallas' 
    );


-- 3.8.查询享有最高销售提成比例的经销商；（请写出不少于三种的不同表示方法）
-- Method 1
SELECT
    *
FROM
    Agents
WHERE
    perc = (
        SELECT
            MAX(perc)
        FROM
            Agents
    );


-- Method 2
SELECT
    *
FROM
    Agents
WHERE
    aid NOT IN (
        SELECT
            a1.aid
        FROM
            Agents a1,
            Agents a2
        WHERE
            a1.aid <> a2.aid
            AND a1.perc < a2.perc
    );


-- Method 3
SELECT
    a.aid,
    a.aname,
    a.city,
    a.perc
FROM
    Agents a
WHERE
    NOT EXISTS (
        SELECT
            *
        FROM
            Agents t
        WHERE
            t.aid <> a.aid
            AND t.perc > a.perc
    );


-- 3.9.查询仅仅通过a04号经销商订购过商品的顾客编号，并给出每个顾客的购买总金额；
SELECT
    cid,
    SUM(dols) AS total_money
FROM
    Orders
GROUP BY
    (cid)
HAVING
    MAX(aid) = 'a04'
    AND MIN(aid) = 'a04';


-- 3.10.查询符合下述要求的经销商的销售统计结果（经销商编号，订单条数，订单的平均销售金额）：
-- 订单的平均销售金额达到或超过500，结果按照订单平均销售金额的降序输出查询结果；
SELECT
    aid,
    COUNT(ordno) AS orders_num,
    (SUM(dols) / COUNT(ordno)) AS average_money
FROM
    Orders
GROUP BY
    aid
HAVING
    (SUM(dols) / COUNT(ordno)) >= 500
ORDER BY
    (SUM(dols) / COUNT(ordno)) DESC;